# Artigos da Internet:
* Intoductuin to Microprocessor Systems:
    Link: http://ece353.engr.wisc.edu/gpio-pins/gpio-pins/
* Getting Started with the TI Stellaris LaunchPad on Linux
    Link: https://www.jann.cc/2012/12/11/getting_started_with_the_ti_stellaris_launchpad_on_linux.html#first-get-a-gcc-cross-compiler-for-arm
* Programming for the Tiva C Launchpad on Linux:
    Link: https://www.strainu.ro/programming/embedded/programming-for-the-tiva-c-launchpad-on-linux/
* HowTo: Develop on the TI Tiva LaunchPad using Linux:
    Link: http://chrisrm.com/howto-develop-on-the-ti-tiva-launchpad-using-linux/
* Embedded Systems - Shape The World (Valvano E-book):
    Link: http://users.ece.utexas.edu/~valvano/Volume1/E-Book/
* Programming the GPIO in TM4C123: 
    Link: http://armofthings.com/2015/11/16/programming-the-gpio/
